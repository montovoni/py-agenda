cores = ("roxo" , "azul", "vermelho" , "amarelo") #TUPLAS SÂO IMUTÀVEIS

for cor in cores:
    print(cor)