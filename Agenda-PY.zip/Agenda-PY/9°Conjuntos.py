conjunto_cores = {"roxo" , "Azul" , "Verde"} #Conunto são aléatorios, não deixa você adicionar coisas repetidas

conjunto_cores.add("branco")
conjunto_cores.add("vermelho")
conjunto_cores.add("roxo")

conjunto_cores.remove("branco")

for cores in conjunto_cores:
    print(cores)
print("FIM DO PROGRAMA")