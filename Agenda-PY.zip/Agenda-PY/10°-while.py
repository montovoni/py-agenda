contador = 0

while contador <10:
    print(contador," - Essa condição é verdadeira")
    contador += 1

print("\nPrograma encerrado!")