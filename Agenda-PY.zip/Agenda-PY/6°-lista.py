nome = "Douglas"
idade = 19

lista = ["Davi" , "Wellington" ,"Geslaine", "Nivaldo", "Lesse", nome, idade] #LISTA DE NOMES
lista.append("Silva") #adiciona a lista
lista.remove("Nivaldo") # remome da lista

print(lista[0])

for c in lista:
    print(c)

for c in nome:
    print(c)
