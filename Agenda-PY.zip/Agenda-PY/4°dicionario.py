nomes = {
    "Douglas": 19,
    "Davi": 13,
    "Wellington": 9,
    "Geslaine": 29,
    "Nivaldo": 32,
    "Lesse": 10,
}

for nome in nomes:
    print(nome)
print("FIM DO PROGRAMA")

for nome in nomes.values():
    print(nome)
print("FIM DO PROGRAMA")

for nome in nomes:
    print(nomes[nome])
print("FIM DO PROGRAMA")

